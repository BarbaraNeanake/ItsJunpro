﻿namespace junpro9
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.rdbSetor = new System.Windows.Forms.RadioButton();
            this.rdbTarik = new System.Windows.Forms.RadioButton();
            this.lblSaldo = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.btnLanjut = new System.Windows.Forms.Button();
            this.textJumlah = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(314, 84);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(189, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Saldo Akun Umum";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(48, 334);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Action:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(48, 387);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(144, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Jumlah Uang:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(48, 440);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(112, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "Password:";
            // 
            // rdbSetor
            // 
            this.rdbSetor.AutoSize = true;
            this.rdbSetor.Location = new System.Drawing.Point(234, 338);
            this.rdbSetor.Name = "rdbSetor";
            this.rdbSetor.Size = new System.Drawing.Size(91, 29);
            this.rdbSetor.TabIndex = 5;
            this.rdbSetor.TabStop = true;
            this.rdbSetor.Text = "setor";
            this.rdbSetor.UseVisualStyleBackColor = true;
            this.rdbSetor.CheckedChanged += new System.EventHandler(this.rdbSetor_CheckedChanged);
            // 
            // rdbTarik
            // 
            this.rdbTarik.AutoSize = true;
            this.rdbTarik.Location = new System.Drawing.Point(345, 338);
            this.rdbTarik.Name = "rdbTarik";
            this.rdbTarik.Size = new System.Drawing.Size(84, 29);
            this.rdbTarik.TabIndex = 6;
            this.rdbTarik.TabStop = true;
            this.rdbTarik.Text = "tarik";
            this.rdbTarik.UseVisualStyleBackColor = true;
            this.rdbTarik.CheckedChanged += new System.EventHandler(this.rdbTarik_CheckedChanged);
            // 
            // lblSaldo
            // 
            this.lblSaldo.AutoSize = true;
            this.lblSaldo.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSaldo.Location = new System.Drawing.Point(208, 139);
            this.lblSaldo.Name = "lblSaldo";
            this.lblSaldo.Size = new System.Drawing.Size(207, 63);
            this.lblSaldo.TabIndex = 7;
            this.lblSaldo.Text = "143132";
            this.lblSaldo.Click += new System.EventHandler(this.lblSaldo_Click);
            // 
            // txtPassword
            // 
            this.txtPassword.HideSelection = false;
            this.txtPassword.Location = new System.Drawing.Point(228, 437);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(499, 31);
            this.txtPassword.TabIndex = 8;
            this.txtPassword.TextChanged += new System.EventHandler(this.txtPassword_TextChanged);
            // 
            // btnLanjut
            // 
            this.btnLanjut.Location = new System.Drawing.Point(624, 525);
            this.btnLanjut.Name = "btnLanjut";
            this.btnLanjut.Size = new System.Drawing.Size(103, 50);
            this.btnLanjut.TabIndex = 9;
            this.btnLanjut.Text = "Lanjut";
            this.btnLanjut.UseVisualStyleBackColor = true;
            this.btnLanjut.Click += new System.EventHandler(this.btnLanjut_Click_1);
            // 
            // textJumlah
            // 
            this.textJumlah.Location = new System.Drawing.Point(228, 387);
            this.textJumlah.Name = "textJumlah";
            this.textJumlah.Size = new System.Drawing.Size(499, 31);
            this.textJumlah.TabIndex = 10;
            this.textJumlah.TextChanged += new System.EventHandler(this.textJumlah_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(811, 666);
            this.Controls.Add(this.textJumlah);
            this.Controls.Add(this.btnLanjut);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.lblSaldo);
            this.Controls.Add(this.rdbTarik);
            this.Controls.Add(this.rdbSetor);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton rdbSetor;
        private System.Windows.Forms.RadioButton rdbTarik;
        private System.Windows.Forms.Label lblSaldo;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Button btnLanjut;
        private System.Windows.Forms.TextBox textJumlah;
    }
}

