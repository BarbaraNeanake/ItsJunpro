﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace junpro9
{
    public partial class Form1 : Form
    {
        private Akun akun;  // Instance kelas Akun
        private string correctPassword = "mama";  // Password untuk validasi transaksi

        public Form1()
        {
            InitializeComponent();
            //akun = new Akun(143132);  // Inisialisasi saldo awal pake class1
            akun = new AkunPremium(143132, 0.05); // pake class 2
            TampilkanSaldo();  // Tampilkan saldo awal di Label
        }

        // Method untuk menampilkan saldo di Label
        private void TampilkanSaldo()
        {
            lblSaldo.Text = "Saldo: " + akun.Saldo.ToString();  // lblSaldo: Label untuk saldo
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            TampilkanSaldo();  // Tampilkan saldo saat form pertama kali dibuka
            txtPassword.PasswordChar = '*';  // Sembunyikan input password dengan '*'
        }

        private void rdbTarik_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void lblSaldo_Click(object sender, EventArgs e)
        {

        }

        private void rdbSetor_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textJumlah_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnLanjut_Click_1(object sender, EventArgs e)
        {
            // Cek apakah password benar
            if (txtPassword.Text != "mama")
            {
                MessageBox.Show("Password salah!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Cek apakah jumlah uang yang dimasukkan valid
            int jumlahUang;
            bool validJumlah = int.TryParse(textJumlah.Text, out jumlahUang);

            if (!validJumlah || jumlahUang <= 0)
            {
                MessageBox.Show("Masukkan jumlah uang yang valid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Cek apakah opsi Setor atau Tarik dipilih
            if (rdbSetor.Checked)
            {
                akun.Setor(jumlahUang);
                MessageBox.Show("Setor berhasil!", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (rdbTarik.Checked)
            {
                if (akun.Tarik(jumlahUang))
                    MessageBox.Show("Tarik berhasil!", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Saldo tidak cukup.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MessageBox.Show("Pilih jenis transaksi (Setor atau Tarik).", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Update saldo setelah transaksi
            TampilkanSaldo();
            // Reset input
            textJumlah.Clear();
            txtPassword.Clear();
        }
    }
}
