﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace ConsoleAppModul10
{
    public partial class Form1 : Form
    {
        List<string> listKota = new List<string>();

        public Form1()
        {
            InitializeComponent();
            listKota = Ongkir.GetKotaList();
            foreach (string kota in listKota)
            {
                tbAsal.AutoCompleteCustomSource.Add(kota);
                tbAsal.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                tbAsal.AutoCompleteSource = AutoCompleteSource.CustomSource;

                tbTujuan.AutoCompleteCustomSource.Add(kota);
                tbTujuan.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                tbTujuan.AutoCompleteSource = AutoCompleteSource.CustomSource;
            }
        }

        private void btnCekHarga_Click_1(object sender, EventArgs e)
        {
            string kurir = "";
            if (rbJne.Checked)
                kurir = "jne";
            else if (rbPos.Checked)
                kurir = "pos";
            else if (rbTiki.Checked)
                kurir = "tiki";

            List<string> daftarLayanan = Ongkir.GetLayananList
                (GetIdKota(tbAsal.Text), GetIdKota(tbTujuan.Text), int.Parse(tbBerat.Text), kurir);
            TampilkanDaftar(daftarLayanan);
        }

        private int GetIdKota(string kota)
        {
            int idKota = -1;
            idKota = Ongkir.GetIdKotaList(kota);
            return idKota;
        }

        private void TampilkanDaftar(List<string> daftarLayanan)
        {
            groupBox1.Text = "Detail Layanan";
            foreach (string layanan in daftarLayanan)
            {
                groupBox1.Text += "\n-" + layanan;
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void rbTiki_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rbPos_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rbJne_CheckedChanged(object sender, EventArgs e)
        {

        }
        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}