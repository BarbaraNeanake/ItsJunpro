﻿namespace ConsoleAppModul10
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblHargaOngkir = new System.Windows.Forms.Label();
            this.lblKota = new System.Windows.Forms.Label();
            this.tbAsal = new System.Windows.Forms.TextBox();
            this.lblTujuan = new System.Windows.Forms.Label();
            this.tbTujuan = new System.Windows.Forms.TextBox();
            this.lblBerat = new System.Windows.Forms.Label();
            this.tbBerat = new System.Windows.Forms.TextBox();
            this.rbPos = new System.Windows.Forms.RadioButton();
            this.rbJne = new System.Windows.Forms.RadioButton();
            this.rbTiki = new System.Windows.Forms.RadioButton();
            this.btnCekHarga = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Location = new System.Drawing.Point(307, 64);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(206, 240);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Detail Layanan";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // lblHargaOngkir
            // 
            this.lblHargaOngkir.AutoSize = true;
            this.lblHargaOngkir.Font = new System.Drawing.Font("MS Reference Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHargaOngkir.Location = new System.Drawing.Point(151, 20);
            this.lblHargaOngkir.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblHargaOngkir.Name = "lblHargaOngkir";
            this.lblHargaOngkir.Size = new System.Drawing.Size(216, 26);
            this.lblHargaOngkir.TabIndex = 1;
            this.lblHargaOngkir.Text = "Cek Harga Ongkir";
            // 
            // lblKota
            // 
            this.lblKota.AutoSize = true;
            this.lblKota.Location = new System.Drawing.Point(23, 64);
            this.lblKota.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblKota.Name = "lblKota";
            this.lblKota.Size = new System.Drawing.Size(115, 13);
            this.lblKota.TabIndex = 2;
            this.lblKota.Text = "Kota / Kabupaten Asal";
            this.lblKota.Click += new System.EventHandler(this.label1_Click);
            // 
            // tbAsal
            // 
            this.tbAsal.Location = new System.Drawing.Point(25, 84);
            this.tbAsal.Margin = new System.Windows.Forms.Padding(2);
            this.tbAsal.Name = "tbAsal";
            this.tbAsal.Size = new System.Drawing.Size(192, 20);
            this.tbAsal.TabIndex = 3;
            // 
            // lblTujuan
            // 
            this.lblTujuan.AutoSize = true;
            this.lblTujuan.Location = new System.Drawing.Point(23, 117);
            this.lblTujuan.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTujuan.Name = "lblTujuan";
            this.lblTujuan.Size = new System.Drawing.Size(128, 13);
            this.lblTujuan.TabIndex = 4;
            this.lblTujuan.Text = "Kota / Kabupaten Tujuan";
            // 
            // tbTujuan
            // 
            this.tbTujuan.Location = new System.Drawing.Point(25, 138);
            this.tbTujuan.Margin = new System.Windows.Forms.Padding(2);
            this.tbTujuan.Name = "tbTujuan";
            this.tbTujuan.Size = new System.Drawing.Size(192, 20);
            this.tbTujuan.TabIndex = 5;
            // 
            // lblBerat
            // 
            this.lblBerat.AutoSize = true;
            this.lblBerat.Location = new System.Drawing.Point(23, 176);
            this.lblBerat.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblBerat.Name = "lblBerat";
            this.lblBerat.Size = new System.Drawing.Size(64, 13);
            this.lblBerat.TabIndex = 6;
            this.lblBerat.Text = "Berat (gram)";
            // 
            // tbBerat
            // 
            this.tbBerat.Location = new System.Drawing.Point(25, 199);
            this.tbBerat.Margin = new System.Windows.Forms.Padding(2);
            this.tbBerat.Name = "tbBerat";
            this.tbBerat.Size = new System.Drawing.Size(192, 20);
            this.tbBerat.TabIndex = 7;
            // 
            // rbPos
            // 
            this.rbPos.AutoSize = true;
            this.rbPos.Location = new System.Drawing.Point(27, 237);
            this.rbPos.Margin = new System.Windows.Forms.Padding(2);
            this.rbPos.Name = "rbPos";
            this.rbPos.Size = new System.Drawing.Size(47, 17);
            this.rbPos.TabIndex = 8;
            this.rbPos.TabStop = true;
            this.rbPos.Text = "POS";
            this.rbPos.UseVisualStyleBackColor = true;
            this.rbPos.CheckedChanged += new System.EventHandler(this.rbPos_CheckedChanged);
            // 
            // rbJne
            // 
            this.rbJne.AutoSize = true;
            this.rbJne.Location = new System.Drawing.Point(100, 237);
            this.rbJne.Margin = new System.Windows.Forms.Padding(2);
            this.rbJne.Name = "rbJne";
            this.rbJne.Size = new System.Drawing.Size(45, 17);
            this.rbJne.TabIndex = 9;
            this.rbJne.TabStop = true;
            this.rbJne.Text = "JNE";
            this.rbJne.UseVisualStyleBackColor = true;
            this.rbJne.CheckedChanged += new System.EventHandler(this.rbJne_CheckedChanged);
            // 
            // rbTiki
            // 
            this.rbTiki.AutoSize = true;
            this.rbTiki.Location = new System.Drawing.Point(174, 237);
            this.rbTiki.Margin = new System.Windows.Forms.Padding(2);
            this.rbTiki.Name = "rbTiki";
            this.rbTiki.Size = new System.Drawing.Size(45, 17);
            this.rbTiki.TabIndex = 10;
            this.rbTiki.TabStop = true;
            this.rbTiki.Text = "TIKI";
            this.rbTiki.UseVisualStyleBackColor = true;
            this.rbTiki.CheckedChanged += new System.EventHandler(this.rbTiki_CheckedChanged);
            // 
            // btnCekHarga
            // 
            this.btnCekHarga.BackColor = System.Drawing.Color.Pink;
            this.btnCekHarga.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCekHarga.Location = new System.Drawing.Point(25, 278);
            this.btnCekHarga.Margin = new System.Windows.Forms.Padding(2);
            this.btnCekHarga.Name = "btnCekHarga";
            this.btnCekHarga.Size = new System.Drawing.Size(191, 40);
            this.btnCekHarga.TabIndex = 11;
            this.btnCekHarga.Text = "Cek Harga Layanan";
            this.btnCekHarga.UseVisualStyleBackColor = false;
            this.btnCekHarga.Click += new System.EventHandler(this.btnCekHarga_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LavenderBlush;
            this.ClientSize = new System.Drawing.Size(533, 340);
            this.Controls.Add(this.btnCekHarga);
            this.Controls.Add(this.rbTiki);
            this.Controls.Add(this.rbJne);
            this.Controls.Add(this.rbPos);
            this.Controls.Add(this.tbBerat);
            this.Controls.Add(this.lblBerat);
            this.Controls.Add(this.tbTujuan);
            this.Controls.Add(this.lblTujuan);
            this.Controls.Add(this.tbAsal);
            this.Controls.Add(this.lblKota);
            this.Controls.Add(this.lblHargaOngkir);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1 Barbara";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblHargaOngkir;
        private System.Windows.Forms.Label lblKota;
        private System.Windows.Forms.TextBox tbAsal;
        private System.Windows.Forms.Label lblTujuan;
        private System.Windows.Forms.TextBox tbTujuan;
        private System.Windows.Forms.Label lblBerat;
        private System.Windows.Forms.TextBox tbBerat;
        private System.Windows.Forms.RadioButton rbPos;
        private System.Windows.Forms.RadioButton rbJne;
        private System.Windows.Forms.RadioButton rbTiki;
        private System.Windows.Forms.Button btnCekHarga;
        public System.Windows.Forms.GroupBox groupBox1;
    }
}